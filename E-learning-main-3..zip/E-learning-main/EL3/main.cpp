#include <iostream>
#include "Bai_1.h"
#include "Bai_2.h"

using namespace std;

int main() {
    int choice;

    do {
        cout << "\n========== E LEARNING 3 ==========\n";
        cout << "1. Bai toan Quy hoach dong\n";
        cout << "2. Bai toan Tham lam\n";
        cout << "0. Thoat chuong trinh\n";
        cout << "==================================\n";
        cout << "Nhap lua chon: ";

        if (!(cin >> choice)) {
            cout << "Du lieu nhap khong hop le!\n";
            return 1;
        }

        switch (choice) {
            case 1:
                cout << "\n--- BAI 1: QUY HOACH DONG ---\n";
                runDP();
                break;
            case 2:
                cout << "\n--- BAI 2: THAM LAM ---\n";
                runGreedy();
                break;
            case 0:
                cout << "Ket thuc chuong trinh!\n";
                break;
            default:
                cout << "Lua chon khong hop le. Vui long chon lai!\n";
        }
    } while (choice != 0);

    return 0;
}
