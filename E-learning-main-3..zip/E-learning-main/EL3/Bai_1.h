#ifndef BAI_1_H
#define BAI_1_H

#include <algorithm>
#include <fstream>
#include <iostream>
#include <limits>
using namespace std;

// Bai 1: Quy hoach dong - tim hinh vuong k x k co tong lon nhat.
inline void runDP() {
    const int MAXN = 1005;
    int n, k;
    long long a[MAXN][MAXN] = {};
    long long dp[MAXN][MAXN] = {};

    ifstream fin("input_B1.txt");
    if (!fin) {
        cout << "Khong the mo file input_B1.txt\n";
        return;
    }

    if (!(fin >> n >> k) || n <= 0 || n >= MAXN || k <= 0 || k > n) {
        cout << "Du lieu n, k khong hop le trong input_B1.txt\n";
        return;
    }

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (!(fin >> a[i][j])) {
                cout << "Du lieu ma tran khong hop le\n";
                return;
            }
        }
    }
    fin.close();

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            dp[i][j] = a[i][j] + dp[i-1][j] + dp[i][j-1] - dp[i-1][j-1];
        }
    }

    long long ans = numeric_limits<long long>::lowest();
    int bestI = 1, bestJ = 1;

    for (int i = 1; i <= n-k+1; ++i) {
        for (int j = 1; j <= n-k+1; ++j) {
            long long sum = dp[i+k-1][j+k-1]
                          - dp[i-1][j+k-1]
                          - dp[i+k-1][j-1]
                          + dp[i-1][j-1];
            if (sum > ans) {
                ans = sum;
                bestI = i;
                bestJ = j;
            }
        }
    }

    ofstream fout("output_B1.txt");
    if (!fout) {
        cout << "Khong the ghi output_B1.txt\n";
        return;
    }
    fout << ans << '\n';
    fout.close();

    cout << "Tong luong vang lon nhat: " << ans << '\n';
    cout << "Vi tri hinh vuong: tu hang " << bestI << ", cot " << bestJ
         << " den hang " << bestI+k-1 << ", cot " << bestJ+k-1 << '\n';
    cout << "Da ghi ket qua vao output_B1.txt\n";
}

#endif
