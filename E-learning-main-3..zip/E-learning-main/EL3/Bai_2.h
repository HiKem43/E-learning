#ifndef BAI_2_H
#define BAI_2_H

#include <algorithm>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

struct Job {
    int start;
    int end;
};

inline bool compareJob(const Job& x, const Job& y) {
    if (x.end != y.end) return x.end < y.end;
    return x.start < y.start;
}

// Bai 2: Tham lam - chon nhieu cong viec khong trung thoi gian nhat.
inline void runGreedy() {
    ifstream fin("input_B2.txt");
    if (!fin.is_open()) {
        cout << "Khong the mo file input_B2.txt\n";
        return;
    }

    int n;
    if (!(fin >> n) || n < 0) {
        cout << "Gia tri n khong hop le trong input_B2.txt\n";
        return;
    }

    vector<Job> jobs;
    jobs.reserve(n);

    for (int i = 0; i < n; ++i) {
        int a, b;
        if (!(fin >> a >> b)) {
            cout << "Du lieu cong viec bi thieu hoac khong hop le\n";
            return;
        }
        if (a > b) {
            cout << "Thoi gian bat dau khong duoc lon hon thoi gian ket thuc\n";
            return;
        }
        jobs.push_back({a, b});
    }
    fin.close();

    sort(jobs.begin(), jobs.end(), compareJob);

    vector<Job> selected;
    int lastEnd = 0;
    bool hasSelected = false;

    for (const Job& job : jobs) {
        if (!hasSelected || job.start >= lastEnd) {
            selected.push_back(job);
            lastEnd = job.end;
            hasSelected = true;
        }
    }

    ofstream fout("output_B2.txt");
    if (!fout.is_open()) {
        cout << "Khong the ghi output_B2.txt\n";
        return;
    }
    fout << selected.size() << '\n';
    fout.close();

    cout << "So cong viec toi da: " << selected.size() << '\n';
    cout << "Cac cong viec duoc chon:";
    for (const Job& job : selected) {
        cout << " [" << job.start << ", " << job.end << "]";
    }
    cout << "\nDa ghi ket qua vao output_B2.txt\n";
}

#endif
